public interface VolumeChangeable {
    void increaseVolume();
    void decreaseVolume();
}
