public class RemoteControl {
    public static void increaseVolume(VolumeChangeable device){
        device.increaseVolume();
    }

    public static void decreaseVolume(VolumeChangeable device){
        device.decreaseVolume();
    }
}
