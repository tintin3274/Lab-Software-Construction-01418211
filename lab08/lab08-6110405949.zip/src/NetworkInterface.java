public interface NetworkInterface {
    void connect(Network network);
    void disconnect(Network network);
}
