public interface Edible {
    int giveEnergy();
}
