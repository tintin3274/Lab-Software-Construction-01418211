public interface Washable {
    void wash();
}
