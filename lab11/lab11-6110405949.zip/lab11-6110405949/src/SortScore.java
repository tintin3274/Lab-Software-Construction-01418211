import java.util.ArrayList;

public interface SortScore {
    void sortScore(ArrayList<Student> students);
}