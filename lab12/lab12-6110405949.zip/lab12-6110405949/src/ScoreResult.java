public interface ScoreResult {
    void result(BowlingGame bowlingGame);
}
